import { Component, OnInit } from '@angular/core';
import { RestAPICallsService } from '../services/rest-apicalls.service';
import { sendMailDetails } from '../Utilities/sendMailDetails';

@Component({
  selector: 'app-draft-mails',
  templateUrl: './draft-mails.component.html',
  styleUrls: ['./draft-mails.component.css'],
})
export class DraftMailsComponent implements OnInit {
  body: any;
  mailArr: any = [];
  email: String = '';
  subject: String = '';
  description: String = '';
  snippet: String = '';
  draftBody: sendMailDetails = {
    email: '',
    description: '',
    subject: '',
    snippet: '',
    sent: false,
  };
  id: string = '';

  constructor(private restAPI: RestAPICallsService) {}

  ngOnInit(): void {
    this.restAPI.getMail().subscribe((data) => {
      console.log(data);
      for (let i = 0; i < data.length; i++) {
        if (!data[i].sent) {
          this.mailArr.push(data[i]);
          console.log(data[i]);
        }
      }
      console.log(this.mailArr);
    });
  }
  checker(event: any) {
    this.email = event.email;
    this.subject = event.subject;
    this.description = event.description;
    this.id = event.id;
    document.getElementById('my')!.style.display = 'block';
  }
  sendMessage() {
    this.draftBody.email = this.email.trim();
    this.draftBody.description = this.description.trim();
    this.draftBody.subject = this.subject.trim();
    this.draftBody.snippet = this.description.substring(0, 10).trim();
    this.draftBody.sent = true;
    console.log(this.draftBody);
    console.log(this.id);
    this.restAPI.deleteMail(this.id).subscribe((data) => {
      console.log(data);
    });
    this.restAPI.sendMail(this.draftBody).subscribe((data) => {
      console.log('----');
      console.log(data);
    });
    document.getElementById('my')!.style.display = 'none';
    location.reload();
  }
  closeForm() {
    this.draftBody.email = this.email.trim();
    this.draftBody.description = this.description.trim();
    this.draftBody.subject = this.subject.trim();
    this.draftBody.snippet = this.description.substring(0, 10).trim();
    this.draftBody.sent = false;
    this.restAPI.findMail(this.id).subscribe((data) => {
      //console.log(data);
      if (data.id == this.id) {
        this.restAPI.putMail(this.id, this.draftBody).subscribe((data) => {
          console.log(data);
        });
      } else {
        this.restAPI.deleteMail(this.id).subscribe((data) => {
          console.log(data);
        });
        this.restAPI.sendMail(this.draftBody).subscribe((data) => {
          console.log(data);
        });
      }
    });
    document.getElementById('my')!.style.display = 'none';
    location.reload();
  }
  deleteMail(event: any){
    this.restAPI.deleteMail(event.id).subscribe((data) => {
      location.reload();
    })
  }
}
