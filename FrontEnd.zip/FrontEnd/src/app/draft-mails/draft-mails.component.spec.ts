import { ComponentFixture, TestBed } from '@angular/core/testing';

import { DraftMailsComponent } from './draft-mails.component';

describe('DraftMailsComponent', () => {
  let component: DraftMailsComponent;
  let fixture: ComponentFixture<DraftMailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ DraftMailsComponent ]
    })
    .compileComponents();

    fixture = TestBed.createComponent(DraftMailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
