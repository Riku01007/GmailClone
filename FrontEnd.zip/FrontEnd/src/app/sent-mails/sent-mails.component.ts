import { Component, OnInit } from '@angular/core';
import { RestAPICallsService } from '../services/rest-apicalls.service';

@Component({
  selector: 'app-sent-mails',
  templateUrl: './sent-mails.component.html',
  styleUrls: ['./sent-mails.component.css']
})
export class SentMailsComponent implements OnInit {
  body:any;
  mailArr:any = [];

  constructor(private restAPI: RestAPICallsService) { }

  ngOnInit(): void {
    this.getSentMail();
    
  }
  getSentMail(){
    this.restAPI.getMail().subscribe((data)=>{
      console.log(data);
      for(let i = 0; i < data.length; i++)
      {
        if(data[i].sent)
        this.mailArr.push(data[i]);
      }
      console.log(this.mailArr);
    })
  }
  deleteMail(event: any){
    this.restAPI.deleteMail(event.id).subscribe((data) => {
      location.reload();
    })
  }

}
