import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-social-tab',
  templateUrl: './social-tab.component.html',
  styleUrls: ['./social-tab.component.css'],
})
export class SocialTabComponent implements OnInit {
  mainBody: any = [];
  routedData: any = [];
  singleHeader: any;
  singleHeaderArray: any = [];
  recipentsName: any;
  recipentsSubject: any;
  mailIdArray: any;
  mainB: any;

  constructor(private router: Router) {}

  ngOnInit(): void {
    document.getElementById('selection')!.style.backgroundColor = 'whitesmoke';
    document.getElementById('selection')!.style.color = 'red';
    document.getElementById('selection')!.style.borderBottom = '3px solid red';
    document.getElementById('non-selection')!.style.backgroundColor = 'none';
    document.getElementById('non-selection')!.style.color = 'none';
    document.getElementById('non-selection')!.style.borderBottom = 'none';
    this.routedData = window.history.state.data;
    this.mailIdArray = window.history.state.data1;
    //console.log(this.routedData.length);
    for (let j = 0; j < this.routedData.length; j++) {
      this.singleHeader = this.routedData[j];
      //console.log(this.singleHeader);
      for (let i = 0; i < this.singleHeader.length; i++) {
        if (this.singleHeader[i].name == 'From')
          this.recipentsName = this.singleHeader[i].value.substring(0, 7) + '...';

        if (this.singleHeader[i].name == 'Subject') {
          this.recipentsSubject =
            this.singleHeader[i].value.substring(0, 50) + '...';
        }
      }
      this.mainBody.push({
        name: this.recipentsName,
        subject: this.recipentsSubject,
        id: '',
      });
    }
    
    for (let i = 0; i < this.mainBody.length; i++) {
      this.mainBody[i].id = this.mailIdArray[i];
    }
    console.log(this.mainBody);
  }

  primaryHandler(): void {
    this.router.navigate(['/']);
  }
}
