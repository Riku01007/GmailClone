import { TestBed } from '@angular/core/testing';

import { RestAPICallsService } from './rest-apicalls.service';

describe('RestAPICallsService', () => {
  let service: RestAPICallsService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(RestAPICallsService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
