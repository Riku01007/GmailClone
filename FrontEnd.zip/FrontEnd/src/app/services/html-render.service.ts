import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, Observable, retry, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class HtmlRenderService {
  headers = { 'content-type': 'application/json' };

  constructor(private httpClient: HttpClient) {}

  getHtmlContent(body: any): Observable<any> {
    console.log(body);
    return this.httpClient
      .post<any>('http://api.page2images.com/html2image', body, {
        headers: this.headers,
      })
      .pipe(retry(1), catchError(this.handleError));
  }
  handleError(er: any) {
    return throwError(() => {
      console.log(er);
    });
  }
}
