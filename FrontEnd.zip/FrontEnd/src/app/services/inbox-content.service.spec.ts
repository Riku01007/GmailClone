import { TestBed } from '@angular/core/testing';

import { InboxContentService } from './inbox-content.service';

describe('InboxContentService', () => {
  let service: InboxContentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(InboxContentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
