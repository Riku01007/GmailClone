import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, Observable, retry, throwError } from 'rxjs';
import { tempMail } from '../Utilities/tempMail';

@Injectable({
  providedIn: 'root',
})
export class InboxContentService {
  access_token: string =
    'ya29.a0AeTM1ifLi17PC5L1Y3FOUWWy8CjBsqqE_Jq3cw4SB_Erv7ia0owUWGEt54beCav90zNDxgCsvyVV72XhwCkEUR1jDgFPxfa-MDbnwqwKvy5Arb65ldQsDCmw4_JD-LlGdyResTjpaL3HvyBBUyhjd-6j885SKwaCgYKAdcSARASFQHWtWOmrs8yZfcLhXATmivqCBe_tw0165';

    emailBody: string = "";
    preEmail: tempMail = new tempMail;

  constructor(private httpClient: HttpClient) {}

  /*Grab id of every message in Inbox*/
  getInboxData(): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${this.access_token}`,
    });
    const requestOptions = { headers: headers };
    return this.httpClient
      .get<any>(
        `https://gmail.googleapis.com/gmail/v1/users/me/messages`,
        requestOptions
      )
      .pipe(retry(1), catchError(this.handleError));
  }

  /*Grab headers of a single E-mail*/
  getIndividualMail(msgId: any): Observable<any> {
    const headers = new HttpHeaders({
      'Content-Type': 'application/json',
      Authorization: `Bearer ${this.access_token}`,
    });
    const requestOptions = { headers: headers };
    return this.httpClient
      .get<any>(
        `https://gmail.googleapis.com/gmail/v1/users/me/messages/${msgId}`,
        requestOptions
      )
      .pipe(retry(1), catchError(this.handleError));
  }
  handleError(er: any) {
    return throwError(() => {
      console.log(er);
    });
  }
  
  
}
