import { TestBed } from '@angular/core/testing';

import { HtmlRenderService } from './html-render.service';

describe('HtmlRenderService', () => {
  let service: HtmlRenderService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(HtmlRenderService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
