import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { catchError, Observable, retry, throwError } from 'rxjs';

@Injectable({
  providedIn: 'root',
})
export class RestAPICallsService {
  headers = { 'content-type': 'application/json' };

  constructor(private httpClient: HttpClient) {}
  sendMail(body: any): Observable<any> {
    console.log(body);
    return this.httpClient
      .post<any>('http://localhost:4500/api/tutorials', body)
      .pipe(retry(1), catchError(this.handleError));
  }
  getMail(): Observable<any> {
    return this.httpClient
      .get<any>('http://localhost:4500/api/tutorial')
      .pipe(retry(1), catchError(this.handleError));
  }
  deleteMail(id:any): Observable<any> {
    return this.httpClient
      .delete<any>(`http://localhost:4500/api/tutorials/${id}`)
      .pipe(retry(1), catchError(this.handleError));
  }
  findMail(id: string): Observable<any> {
    return this.httpClient.get<any>(`http://localhost:4500/api/tutorials/${id}`)
      .pipe(retry(1), catchError(this.handleError));
  }
  putMail(id: string, body:any): Observable<any> {
    return this.httpClient.put<any>(`http://localhost:4500/api/tutorials/${id}`,body)
      .pipe(retry(1), catchError(this.handleError));
  } 
  handleError(er: any) {
    return throwError(() => {
      console.log(er);
    });
  }
}
