export class tempMail{
    emailBody:string = `Good morning, \[Client\],I would like to formally introduce myself. My name is \[name\] and I am from \[company\], a company focused on \[industry\]. We understand the importance of \[topic that relates to the customer's needs\]. If you are interested in our services, please contact me at \[contact information\]. I'm looking forward to hearing from you!
    
    Best,
    
    \[Name\]  
    \[Phone number\]  
    \[Email address\]`
}