export class inboxDetails{
    name: String = "";
    snippet: String = "";
    time: String = "";
}