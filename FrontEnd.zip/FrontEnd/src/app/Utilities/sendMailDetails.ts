export class sendMailDetails{
    email: String = "";
    description: String = "";
    subject: String = "";
    snippet: String = "";
    sent: boolean = false;
}