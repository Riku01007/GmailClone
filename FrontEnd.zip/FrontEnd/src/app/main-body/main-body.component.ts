import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InboxContentService } from '../services/inbox-content.service';
import { tempMail } from '../Utilities/tempMail';

@Component({
  selector: 'app-main-body',
  templateUrl: './main-body.component.html',
  styleUrls: ['./main-body.component.css'],
})
export class MainBodyComponent implements OnInit {
  inboxData: any;
  dummy: any = [];
  inboxHeaders = [];
  recipentsName: any;
  sendersList: any;
  mailId: any;
  singleHeader: any;
  recipentsSubject: any;
  mainBody: any = [];
  id: String = '';
  mailIdArray: any = [];
  promotionArray: any = [];
  preEmail: tempMail = new tempMail;
  constructor(
    private inboxService: InboxContentService,
    private router: Router
  ) {}

  ngOnInit(): void {
    this.inboxService.getInboxData().subscribe((data) => {
      this.inboxData = data.messages;
      setTimeout(() => {
        for (let i = 0; i < 50; i++) {
          this.mailId = this.inboxData[i].id;
          this.mailIdArray.push(this.mailId);
          this.inboxService.getIndividualMail(this.mailId).subscribe((data) => {
           console.log("@");

            //Separating sent items from inbox

            if (data.labelIds.length == 1) {
              this.sendersList = data;
            } else {
              for (let i = 0; i < data.labelIds.length; i++) {
                if (data.labelIds[i] === 'CATEGORY_SOCIAL') {
                  console.log(this.mailId);
                  console.log(data.payload);
                  this.promotionArray.push(data.payload.headers);
                }
              }
              this.inboxHeaders = data.payload.headers;
              this.dummy.push(data.payload.headers);
            }
            for (let j = 0; j < this.inboxHeaders.length; j++) {
              this.singleHeader = this.inboxHeaders[j];

              if (this.singleHeader.name == 'From')
                this.recipentsName =
                  this.singleHeader.value.substring(0, 7) + '...';

              if (this.singleHeader.name == 'Subject') {
                this.recipentsSubject =
                  this.singleHeader.value.substring(0, 50) + '...';
              }
            }
            this.mainBody.push({
              name: this.recipentsName,
              subject: this.recipentsSubject,
              id: '',
            });
            for (let i = 0; i < this.mainBody.length; i++) {
              this.mainBody[i].id = this.mailIdArray[i];
            }
          });
        }
      }, 3000);
    });
  }
  nextPage(event: any) {
    console.log(event);
    this.router.navigate(['/mail'], { state: { data: event } });
  }

  socialHandler() {
    this.router.navigate(['/social'], {
      state: { data: this.promotionArray, data1: this.mailIdArray },
    });
  }

  prePopEmail(){
    
  }
}
