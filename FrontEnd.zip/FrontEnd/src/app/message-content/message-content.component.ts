import { Component, OnInit, PipeTransform, Pipe } from '@angular/core';



@Component({
  selector: 'app-message-content',
  templateUrl: './message-content.component.html',
  styleUrls: ['./message-content.component.css']
})

export class MessageContentComponent implements OnInit {

  constructor() { }


  ngOnInit(): void {
    
  }

}
