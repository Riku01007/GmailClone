import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { InboxContentService } from '../services/inbox-content.service';
import { RestAPICallsService } from '../services/rest-apicalls.service';
import { sendMailDetails } from '../Utilities/sendMailDetails';

@Component({
  selector: 'app-side-bar',
  templateUrl: './side-bar.component.html',
  styleUrls: ['./side-bar.component.css'],
})
export class SideBarComponent implements OnInit {
  email: String = '';
  subject: String = '';
  description: String = '';
  snippet: String = '';
  body: sendMailDetails = {
    email: '',
    description: '',
    subject: '',
    snippet: '',
    sent: false,
  };
  emailD:string = "";

  constructor(private restAPICalls: RestAPICallsService, private router: Router) {}

  ngOnInit(): void {
    
  }
  composeHandler() {
    document.getElementById('myForm')!.style.display = 'block';
    document.getElementById('abc_icon')!.style.display = 'inline';
  }
  closeForm() {
    console.log("@");
    if (this.email.length > 0) {
      this.body.email = this.email.trim();
      this.body.description = this.description.trim();
      this.body.subject = this.subject.trim();
      this.body.snippet = this.description.substring(0, 10).trim();
      this.body.sent = false;
      this.restAPICalls.sendMail(this.body).subscribe((data) => {
        //console.log(data);
      });
    }
    document.getElementById('myForm')!.style.display = 'none';
    document.getElementById('abc_icon')!.style.display = 'none';
  }
  sendMessage() {
    this.body.email = this.email.trim();
    this.body.description = this.description.trim();
    this.body.subject = this.subject.trim();
    this.body.snippet = this.description.substring(0, 10).trim();
    this.body.sent = true;
    console.log(this.body);
    this.restAPICalls.sendMail(this.body).subscribe((data) => {
      console.log(data);
    });
    this.email = '';
    this.description = '';
    this.subject = '';
    document.getElementById('myForm')!.style.display = 'none';
  }

  primaryHandler():void {
    this.router.navigate(["/"]);
  }
}
