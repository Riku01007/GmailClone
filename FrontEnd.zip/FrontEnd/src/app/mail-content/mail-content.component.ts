import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { HtmlRenderService } from '../services/html-render.service';
import { InboxContentService } from '../services/inbox-content.service';

@Component({
  selector: 'app-mail-content',
  templateUrl: './mail-content.component.html',
  styleUrls: ['./mail-content.component.css'],
})
export class MailContentComponent implements OnInit {
  //declare Buffer: any;
  product: any;
  data: any;
  htmlContent: string = '';
  body: any;

  constructor(private router: Router, private services: InboxContentService, private htmlServices: HtmlRenderService) {
    this.product = this.router.getCurrentNavigation()?.extras.state;

    this.data = this.product.data;
    this.services.getIndividualMail(this.data.id).subscribe((d) => {
      if(d.payload.body.data == undefined)
      this.htmlContent = d.payload.parts[1].body.data;
      else if(d.payload.parts == undefined)      
      this.htmlContent = d.payload.body.data;
      var re = /-/gi;
      var reg = /_/gi;
      var s1 = this.htmlContent.replace(re, '+');
      var s2 = s1.replace(reg, '/');
      var s3 = window.atob(s2);
      document.getElementsByClassName("divTag")[0].innerHTML = s3;
      this.body = {
        "p2i_html": "<div>test</div>",
        "p2i_key": "889778a6a8988755"
      }
    });
  }

  ngOnInit(): void {
    
  }
}
