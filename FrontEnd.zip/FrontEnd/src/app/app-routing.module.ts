import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { DraftMailsComponent } from './draft-mails/draft-mails.component';
import { MailContentComponent } from './mail-content/mail-content.component';
import { MainBodyComponent } from './main-body/main-body.component';
import { MessageContentComponent } from './message-content/message-content.component';
import { SentMailsComponent } from './sent-mails/sent-mails.component';
import { SocialTabComponent } from './social-tab/social-tab.component';

const routes: Routes = [
  {path:'', component: MainBodyComponent},
  {path:'message', component: MessageContentComponent},
  {path:'mail', component: MailContentComponent},
  {path:'sent', component: SentMailsComponent},
  {path:'draft', component: DraftMailsComponent},
  {path:'social', component: SocialTabComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
