import { NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { HttpClientModule } from '@angular/common/http';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule } from '@angular/forms';
import { HeaderComponent } from './header/header.component';
import { MainBodyComponent } from './main-body/main-body.component';
import { SideBarComponent } from './side-bar/side-bar.component';
import { MessageContentComponent } from './message-content/message-content.component';
import { MailContentComponent } from './mail-content/mail-content.component';
import { SentMailsComponent } from './sent-mails/sent-mails.component';
import { DraftMailsComponent } from './draft-mails/draft-mails.component';
import { SocialTabComponent } from './social-tab/social-tab.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    MainBodyComponent,
    SideBarComponent,
    MessageContentComponent,
    MailContentComponent,
    SentMailsComponent,
    DraftMailsComponent,
    SocialTabComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
